package com.mera.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var cmd: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 90, 40, 40) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        root.addView(TextView(this).apply { text = "Mera Assistant"; textSize = 26f })
        val key = EditText(this).apply {
            hint = "Claude API key yahan paste karo"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        root.addView(key)
        root.addView(btn("1. Key save karo") {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            Toast.makeText(this, "Key save ho gayi", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("2. Accessibility ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        cmd = EditText(this).apply { hint = "Kya karna hai? (jaise: WhatsApp kholo)" }
        root.addView(cmd)
        root.addView(btn("3. Chalao") { go(cmd.text.toString()) })
        root.addView(btn("Bol kar command do") {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            try { startActivityForResult(i, 1) } catch (e: Exception) {
                Toast.makeText(this, "Voice input available nahi", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(btn("ROKO (Stop)") { AssistantService.stop = true })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun go(c: String) {
        if (c.isBlank()) return
        val s = AssistantService.instance
        if (s == null) {
            Toast.makeText(this, "Pehle Accessibility ON karo", Toast.LENGTH_LONG).show(); return
        }
        if (getSharedPreferences("p", MODE_PRIVATE).getString("key", "").isNullOrBlank()) {
            Toast.makeText(this, "Pehle API key save karo", Toast.LENGTH_LONG).show(); return
        }
        s.runCommand(c)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            cmd.setText(t)
            go(t)
        }
    }
}
