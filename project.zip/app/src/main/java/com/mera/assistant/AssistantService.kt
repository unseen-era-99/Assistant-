package com.mera.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AssistantService : AccessibilityService() {
    companion object {
        var instance: AssistantService? = null
        @Volatile var stop = false
        @Volatile var busy = false
        const val SYSTEM = "Tum ek Android phone control agent ho. User ka kaam aur current screen diya jayega. " +
            "Screen ke har item ka number hota hai. Sirf EK JSON object do, aur kuch nahi. Formats: " +
            "{\"action\":\"open_app\",\"app\":\"WhatsApp\"} | {\"action\":\"click\",\"id\":5} | " +
            "{\"action\":\"type\",\"id\":3,\"text\":\"hello\"} | {\"action\":\"scroll_down\"} | {\"action\":\"scroll_up\"} | " +
            "{\"action\":\"back\"} | {\"action\":\"home\"} | {\"action\":\"wait\"} | " +
            "{\"action\":\"done\",\"say\":\"user ke liye chhota Hinglish message\"}. " +
            "Kaam poora ho jaye to done do. Safety: user ne saaf na kaha ho to payment, password/OTP daalna, " +
            "data delete karna ya message bhejna MAT karo; aise mod par done do aur say mein user se poochho."
    }

    private val ui = Handler(Looper.getMainLooper())
    private var nodes = listOf<AccessibilityNodeInfo>()

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }

    private fun say(t: String) { ui.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() } }

    fun runCommand(task: String) {
        if (busy) { say("Pehle wala kaam chal raha hai"); return }
        busy = true; stop = false
        Thread {
            try { loop(task) } catch (e: Exception) { say("Error: " + e.message) }
            busy = false
        }.start()
    }

    private fun loop(task: String) {
        val log = StringBuilder()
        for (step in 1..20) {
            if (stop) { say("Roka gaya"); return }
            val msg = "Kaam: " + task + "\nPehle ke actions:\n" + log + "\nAbhi screen:\n" + dump()
            val out = ask(msg)
            val j = JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
            log.append(step).append(". ").append(out.take(150)).append("\n")
            when (j.optString("action")) {
                "click" -> click(j.optInt("id"))
                "type" -> type(j.optInt("id"), j.optString("text"))
                "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                "scroll_down" -> scroll(true)
                "scroll_up" -> scroll(false)
                "open_app" -> openApp(j.optString("app"))
                "done" -> { say(j.optString("say", "Ho gaya")); return }
            }
            Thread.sleep(1800)
        }
        say("20 steps ho gaye, ruk gaya")
    }

    private fun dump(): String {
        val l = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || l.size > 120) return
            val t = (n.text ?: n.contentDescription)?.toString()?.take(60) ?: ""
            if (t.isNotEmpty() || n.isClickable || n.isEditable || n.isScrollable) {
                sb.append(l.size).append(": ").append(n.className.toString().substringAfterLast('.'))
                    .append(" \"").append(t).append("\"")
                if (n.isClickable) sb.append(" [click]")
                if (n.isEditable) sb.append(" [edit]")
                if (n.isScrollable) sb.append(" [scroll]")
                sb.append("\n")
                l.add(n)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        val root = rootInActiveWindow
        walk(root)
        nodes = l
        return "App: " + root?.packageName + "\n" + sb
    }

    private fun ask(msg: String): String {
        val key = getSharedPreferences("p", MODE_PRIVATE).getString("key", "")
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 300).put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", msg)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.doOutput = true; c.connectTimeout = 20000; c.readTimeout = 60000
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code >= 400) throw Exception("API " + code + ": " + txt.take(150))
        return JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
    }

    private fun click(id: Int) {
        var n = nodes.getOrNull(id)
        while (n != null && !n.isClickable) n = n.parent
        n?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun type(id: Int, t: String) {
        val n = nodes.getOrNull(id) ?: return
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun scroll(fwd: Boolean) {
        nodes.firstOrNull { it.isScrollable }?.performAction(
            if (fwd) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
        val m = apps.firstOrNull { pm.getApplicationLabel(it).toString().equals(name, true) }
            ?: apps.firstOrNull { pm.getApplicationLabel(it).toString().contains(name, true) }
        val i = m?.let { pm.getLaunchIntentForPackage(it.packageName) } ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }
}
